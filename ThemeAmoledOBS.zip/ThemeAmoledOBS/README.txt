ThemeAmoledOBS - tema para OBS Studio
=====================================

Tema negro AMOLED en escala de grises para OBS Studio 30.2+
(basado en Yami). Con bandas del mezclador y bordes de fuente
en escala blanca casi pura para look minimalista pleno.

Version: ThemeAmoledOBS (bordes blancos, meter unificado)
Licencia: Dominio publico / CC0
Autor: Anonimo


Contenido del paquete
---------------------
- ThemeAmoledOBS.ovt                       Archivo principal del tema.
- ThemeAmoledOBS/                          Assets PNG opcionales
                                           (checkbox, radio, sizegrip,
                                           hooks).
- ThemeAmoledOBS - Accesibilidad.ini       Bloque de Accesibilidad con
                                           los colores de borde de
                                           fuente y mezclador.
- README.txt                               Este archivo.


Instalacion del tema
--------------------
macOS:
  Copiar "ThemeAmoledOBS.ovt" y la carpeta "ThemeAmoledOBS" a:
    ~/Library/Application Support/obs-studio/themes/
  O al directorio del sistema:
    /Applications/OBS.app/Contents/Resources/themes/

Windows:
  %APPDATA%\obs-studio\themes\

Linux:
  ~/.config/obs-studio/themes/

Luego abrir OBS -> Ajustes -> Apariencia -> Tema: ThemeAmoledOBS.


Aplicar bordes blancos de fuente (paso necesario)
-------------------------------------------------
OBS guarda los colores de los bordes de fuente (seleccion, recorte,
hover) fuera del archivo .ovt, en Accesibilidad. Las bandas del
mezclador YA estan empotradas en el .ovt y no requieren este paso,
pero los bordes blancos si.

Opcion A - Ruta manual en OBS (recomendada para principiantes):
  Ajustes -> Accesibilidad -> Reemplazo de colores -> Personalizado
  Activar "Usar otros colores".

  Valores visuales:
    Borde de la fuente (seleccion):           #EFFFF1
    Borde de la fuente (recorte):             #F9FFFB
    Borde de la fuente (al pasar por encima): #E9EFE8

  (Las bandas del mezclador se pueden dejar como vienen porque el
  tema ya las aplica. Si quieres asegurar consistencia, copia tambien
  los valores del .ini.)

Opcion B - Editar user.ini directamente (avanzado):
  1. Cerrar OBS por completo (Cmd+Q o quit, no solo cerrar ventana).
  2. Abrir el archivo:
       macOS:   ~/Library/Application Support/obs-studio/user.ini
       Windows: %APPDATA%\obs-studio\user.ini
       Linux:   ~/.config/obs-studio/user.ini
  3. Pegar el contenido de "ThemeAmoledOBS - Accesibilidad.ini"
     dentro del bloque [Accessibility] (o reemplazar el bloque entero).
  4. Guardar y reabrir OBS.


Lo que NO se puede empotrar en el tema
--------------------------------------
- Los bordes de seleccion/recorte/hover del lienzo de preview son
  hardcoded en OBS y solo se controlan via Accesibilidad. No existe
  qproperty-selectColor, qproperty-cropColor ni qproperty-hoverColor
  para OBSBasicPreview en ninguna version actual. Por eso se entrega
  el .ini aparte.
- En macOS Sequoia/Tahoe (15+), el indicador de privacidad de captura
  de pantalla (borde azul/amarillo alrededor de regiones capturadas)
  es dibujado por el sistema, no por OBS. No se puede ocultar desde
  el tema ni desde defaults. Usar Captura de Ventana en lugar de
  Captura de Pantalla minimiza el efecto.


Nota sobre meter del mezclador
------------------------------
Las bandas del mezclador (qproperty-backgroundNominalColor /
WarningColor / ErrorColor y sus variantes *Disabled) estan unificadas
para que tanto sources "Active" como "Inactive" muestren las 3 bandas
grises consistentes. Empiricamente OBS aplica las qproperties con
sufijo "Disabled" al label "Active" del mixer, asi que ambos sets
quedan identicos para evitar la asimetria visual.


Privacidad y origen
-------------------
Este paquete contiene exclusivamente archivos del tema, assets PNG
genericos y un fragmento de colores de Accesibilidad. NO incluye
escenas, perfiles, claves de transmision, cuentas, capturas ni
logs de uso. Es seguro publicar y redistribuir.
